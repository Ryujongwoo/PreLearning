
public class HelloJava {

	public static void main(String[] args) {
		
//		1줄 주석
		/*
		범위, 여러줄 주석  
		*/
//		println(): 괄호 안의 내용을 출력하고 줄을 바꾼다.
//		print(): 괄호 안의 내용을 출력하고 줄을 바꾸지 않는다.
//		printf(): 출력 서식을 지정해서 출력한다.
		System.out.print("안녕 자바"); 
		System.out.println("안녕 \n자바"); // \n: new line, 줄을 바꾼다.
		System.out.println("안녕 자바"); 
		
	}
	
}
