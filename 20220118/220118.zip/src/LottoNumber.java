
public class LottoNumber {

	public static void main(String[] args) {
		
		int a = 3, b = 4;
		System.out.println("a = " + a + ", b = " + b);
		
		int temp = a;
		a = b;
		b = temp;
		System.out.println("a = " + a + ", b = " + b);
		
	}
	
}
